#
# Example shell file for starting ./PhoenixMiner to mine ETH
#

# IMPORTANT: Replace the ETH address with your own ETH wallet address in the -wal option (Rig001 is the name of the rig)
./PhoenixMiner -pool asia-eth.2miners.com:2020 -wal 0x4bd312b31f03bdc6449af051d198decb19285460.RIG_ID3 -rmode 2
